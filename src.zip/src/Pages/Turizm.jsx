import React from "react";

const Turizm = () => {
  return <div>Turizm</div>;
};

export default Turizm;
