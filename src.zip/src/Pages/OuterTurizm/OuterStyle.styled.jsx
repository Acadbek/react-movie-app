import styled from "styled-components";

export const OuterContainer = styled.div`
  color: red;
  height: 50vh;
`;
